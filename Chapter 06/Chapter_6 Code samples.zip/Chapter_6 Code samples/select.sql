SELECT *
FROM customers;

SELECT customer_id, first_name, last_name
FROM customers;
