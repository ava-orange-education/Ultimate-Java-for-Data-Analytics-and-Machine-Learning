MERGE INTO customers AS target
USING customers_new AS source
ON target.customer_id = source.customer_id
WHEN MATCHED THEN
  UPDATE SET target.customer_name = source.customer_name, target.customer_email = source.customer_email, target.customer_phone = source.customer_phone
WHEN NOT MATCHED THEN
  INSERT (customer_id, customer_name, customer_email, customer_phone) VALUES (source.customer_id, source.customer_name, source.customer_email, source.customer_phone);
