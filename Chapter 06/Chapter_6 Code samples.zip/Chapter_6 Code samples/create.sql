-- Create a new database
CREATE DATABASE mydatabase;

-- Switch to the new database
USE mydatabase;

-- Create a new table with columns
CREATE TABLE customers (
  customer_id INT PRIMARY KEY,
  customer_name VARCHAR(50),
  customer_email VARCHAR(50),
  customer_phone VARCHAR(20)
);
