BEGIN TRANSACTION;

INSERT INTO customers (customer_id, customer_name, customer_email, customer_phone)
VALUES (1, 'John', 'john@example.com', '1234567890');

UPDATE customers
SET customer_phone = '9876543210'
WHERE customer_id = 1;

ROLLBACK;
