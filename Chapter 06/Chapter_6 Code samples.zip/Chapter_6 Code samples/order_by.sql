SELECT order_id, order_total
FROM orders
ORDER BY order_total DESC;
