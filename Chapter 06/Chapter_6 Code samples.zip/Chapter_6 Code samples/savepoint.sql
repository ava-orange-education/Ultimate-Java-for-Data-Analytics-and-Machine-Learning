SAVEPOINT before_update;

UPDATE customers
SET customer_email = 'new_email@example.com'
WHERE customer_id = 123;

ROLLBACK TO before_update;