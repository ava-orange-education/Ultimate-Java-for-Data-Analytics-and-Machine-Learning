-- INNER JOIN
SELECT students.student_name, marks.marks
FROM students
INNER JOIN marks
ON students.student_id = marks.student_id;

-- LEFT JOIN
SELECT students.student_id, students.student_name, marks.marks
FROM students
LEFT JOIN marks
ON students.student_id = marks.student_id;

-- RIGHT JOIN
SELECT *
FROM marks
RIGHT JOIN students
ON marks.student_id = students.student_id;

-- FULL OUTER JOIN
SELECT students.student_id, students.student_name, marks.marks
FROM students
FULL OUTER JOIN marks
ON students.student_id = marks.student_id;
