SELECT customer_id, SUM(order_total) AS total_orders
FROM orders
GROUP BY customer_id;
