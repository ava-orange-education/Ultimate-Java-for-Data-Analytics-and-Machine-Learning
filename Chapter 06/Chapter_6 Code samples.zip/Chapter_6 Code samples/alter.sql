ALTER TABLE customers
ADD country varchar(50);

ALTER TABLE customers
RENAME COLUMN customer_phone TO phone;

ALTER TABLE customers
DROP COLUMN email;
