DELETE FROM table_name WHERE condition;

DELETE FROM customers WHERE customer_id = 2;