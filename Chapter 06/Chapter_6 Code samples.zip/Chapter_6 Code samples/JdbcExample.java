import java.sql.*;

public class JdbcExample {
    public static void main(String[] args) {
        try {
            // Step 1: Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Step 2: Establish a connection to the MySQL database
            String url = "jdbc:mysql://localhost:3306/mydatabase";
            String username = "root";
            String password = "admin";
            Connection conn = DriverManager.getConnection(url, username, password);

            // Step 3: Execute a SQL statement
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM customers");

            // Step 4: Process the result set
            while (rs.next()) {
                int id = rs.getInt("customer_id");
                String name = rs.getString("customer_name");
                String email = rs.getString("customer_email");
                String phone = rs.getString("customer_phone");
                System.out.println("ID: " + id + ", Name: " + name + ", Email: " + email + ", Phone: " + phone);
            }

            // Step 5: Close the connection and statement objects
            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException ex) {
            System.out.println("SQL exception: " + ex.getMessage());
        } catch (ClassNotFoundException ex) {
            System.out.println("Driver not found: " + ex.getMessage());
        }
    }
}
