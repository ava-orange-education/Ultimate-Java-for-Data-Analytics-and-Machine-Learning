INSERT INTO customers (customer_id, customer_name, customer_email, customer_phone)
VALUES (1, 'John Smith', 'john.smith@example.com', '123-456-7890');

COMMIT;
