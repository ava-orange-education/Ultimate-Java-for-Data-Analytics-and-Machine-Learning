INSERT INTO customers (customer_id, customer_name, customer_email, customer_phone)
VALUES (1, 'John Doe', 'johndoe@example.com', '555-1234');

INSERT INTO customers (customer_id, customer_name, customer_email, customer_phone)
VALUES
(1, 'John Doe', 'johndoe@example.com', '555-1234'),
(2, 'Jane Doe', 'janedoe@example.com', '555-5678'),
(3, 'Bob Smith', 'bobsmith@example.com', '555-9012');

