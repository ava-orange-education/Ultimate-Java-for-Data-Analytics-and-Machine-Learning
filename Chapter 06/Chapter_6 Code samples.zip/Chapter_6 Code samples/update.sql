UPDATE customers
SET customer_phone = '555-9013'
WHERE customer_name = 'Bob Smith';

UPDATE customers
SET customer_phone = '555-9014', customer_email = 'bob.smith@example2.com'
WHERE customer_name = 'Bob Smith';
