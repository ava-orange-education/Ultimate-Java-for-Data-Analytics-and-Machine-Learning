import org.apache.commons.math3.stat.descriptive.rank.Median;

public class MedianExample {
    public static void main(String[] args) {
        // Create an array of values
        double[] values = {2, 3, 5, 7, 10, 12, 15};

        // Calculate the median
        Median median = new Median();
        double medianValue = median.evaluate(values);
        System.out.println("Median: " + medianValue);
    }
}
