import org.apache.commons.math3.distribution.GeometricDistribution;

public class GeometricExample {
    public static void main(String[] args) {
        int numTrials = 5;
        double successProbability = 0.5;

        GeometricDistribution geometric = new GeometricDistribution(successProbability);

        for (int i = 1; i <= numTrials; i++) {
            double probability = geometric.probability(i);
            System.out.printf("Probability of getting the first head in %d trials: %.3f\n", i, probability);
        }
    }
}
