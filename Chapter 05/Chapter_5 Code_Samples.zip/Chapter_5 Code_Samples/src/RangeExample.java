import org.apache.commons.math3.stat.StatUtils;

public class RangeExample {
    public static void main(String[] args) {
        double[] data = {2.1, 4.5, 1.2, 6.9, 3.8, 6.5};
      
        double max = StatUtils.max(data);
        double min = StatUtils.min(data);
      
        double range = max - min;

        System.out.println("Range: " + range);
    }
}
