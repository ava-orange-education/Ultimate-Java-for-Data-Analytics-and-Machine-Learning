import org.apache.commons.math3.stat.inference.TTest;

public class HypothesisTestExample {
    public static void main(String[] args) {
        double[] scores = {80, 72, 90, 85, 78, 79, 70, 88, 92, 83, 
                           75, 81, 87, 86, 76, 84, 91, 77, 82, 89};
        
        double mean = 0;
        for (double score : scores) {
            mean += score;
        }
        mean /= scores.length;

        double stdDev = 0;
        for (double score : scores) {
            stdDev += Math.pow(score - mean, 2);
        }
        stdDev /= scores.length - 1;
        stdDev = Math.sqrt(stdDev);

        double t = (mean - 75) / (stdDev / Math.sqrt(scores.length));
        TTest tTest = new TTest();
        double pValue = tTest.tTest(75, scores);

        System.out.println("Sample mean: " + mean);
        System.out.println("Standard deviation: " + stdDev);
        System.out.println("t-value: " + t);
        System.out.println("p-value: " + pValue);

        if (pValue < 0.05) {
            System.out.println("Reject null hypothesis");
        } else {
            System.out.println("Cannot reject null hypothesis");
        }
    }
}
