import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

public class OutlierExample {
    public static void main(String[] args) {
        // Example data
        double[] data = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 100};

        // Calculate mean and standard deviation
        DescriptiveStatistics stats = new DescriptiveStatistics();
        for (double d : data) {
            stats.addValue(d);
        }
        double mean = stats.getMean();
        double stdDev = stats.getStandardDeviation();

        // Calculate Z-score for each data point
        for (double d : data) {
            double zScore = (d - mean) / stdDev;
            if (Math.abs(zScore) > 2) {  // Threshold of 2
                System.out.println(d + " is an outlier.");
            }
        }
    }
}
