import java.util.ArrayList;
import java.util.Random;

public class RandomSamplingExample {

   public static void main(String[] args) {
      
      // create a list of data points
      ArrayList<Integer> data = new ArrayList<Integer>();
      for(int i = 1; i <= 100; i++) {
         data.add(i);
      }
      
      // create a random number generator
      Random random = new Random();
      
      // perform random sampling
      ArrayList<Integer> sample = new ArrayList<Integer>();
      for(int i = 0; i < 10; i++) {
         int index = random.nextInt(data.size());
         int value = data.get(index);
         sample.add(value);
         data.remove(index);
      }
      
      // print the sample
      System.out.println("Random sample: " + sample);
   }
}
