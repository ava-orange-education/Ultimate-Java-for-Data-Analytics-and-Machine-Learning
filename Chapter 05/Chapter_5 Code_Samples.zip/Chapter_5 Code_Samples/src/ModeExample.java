import org.apache.commons.math3.stat.StatUtils;

public class ModeExample {
    public static void main(String[] args) {
        // Create an array of values
        double[] values = {2, 4, 5, 5, 6, 6, 6, 8};

        // Calculate the mode
        double[] mode = StatUtils.mode(values);
        System.out.print("Mode: ");
        for(double m : mode) {
            System.out.print(m + " ");
        }
    }
}
