import org.apache.commons.math3.distribution.NormalDistribution;

public class CentralLimitTheoremExample {
    public static void main(String[] args) {
        int n = 1000; // number of samples to generate
        int m = 1000; // number of times to repeat the experiment
        double mean = 5; // mean of the underlying distribution
        double stdDev = 2; // standard deviation of the underlying distribution

        NormalDistribution normal = new NormalDistribution(mean, stdDev); // create the underlying distribution

        double[] sampleMeans = new double[m]; // array to hold the sample means

        for (int i = 0; i < m; i++) {
            double sum = 0;
            for (int j = 0; j < n; j++) {
                sum += normal.sample(); // generate a random sample from the underlying distribution
            }
            sampleMeans[i] = sum / n; // calculate the sample mean and store it in the array
        }

        // Calculate the mean and standard deviation of the sample means
        double sampleMean = calculateMean(sampleMeans);
        double sampleStdDev = calculateStandardDeviation(sampleMeans, sampleMean);

        // Print the results
        System.out.println("Underlying distribution: mean = " + mean + ", stdDev = " + stdDev);
        System.out.println("Sample mean: " + sampleMean);
        System.out.println("Sample standard deviation: " + sampleStdDev);
    }

    // Helper method to calculate the mean of an array of doubles
    private static double calculateMean(double[] data) {
        double sum = 0;
        for (double x : data) {
            sum += x;
        }
        return sum / data.length;
    }

    // Helper method to calculate the standard deviation of an array of doubles, given the mean
    private static double calculateStandardDeviation(double[] data, double mean) {
        double sum = 0;
        for (double x : data) {
            sum += Math.pow(x - mean, 2);
        }
        return Math.sqrt(sum / (data.length - 1));
    }
}
