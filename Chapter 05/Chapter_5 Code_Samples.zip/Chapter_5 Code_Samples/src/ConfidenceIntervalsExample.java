import org.apache.commons.math3.distribution.NormalDistribution;

public class ConfidenceIntervalsExample {
    public static void main(String[] args) {
        // Generate sample data
        double[] data = {10.0, 12.0, 15.0, 13.0, 11.0, 14.0, 16.0, 9.0, 10.0, 12.0};

        // Compute sample mean and standard deviation
        double mean = 0.0;
        double variance = 0.0;
        for (double d : data) {
            mean += d;
        }
        mean /= data.length;
        for (double d : data) {
            variance += Math.pow(d - mean, 2);
        }
        variance /= data.length - 1;
        double stdDev = Math.sqrt(variance);

        // Compute confidence interval at 95% confidence level
        NormalDistribution dist = new NormalDistribution();
        double z = dist.inverseCumulativeProbability(0.975);
        double marginOfError = z * stdDev / Math.sqrt(data.length);
        double lowerBound = mean - marginOfError;
        double upperBound = mean + marginOfError;

        // Output results
        System.out.println("Sample mean: " + mean);
        System.out.println("Standard deviation: " + stdDev);
        System.out.println("95% confidence interval: [" + lowerBound + ", " + upperBound + "]");
    }
}
