import org.apache.commons.math3.distribution.NormalDistribution;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.statistics.HistogramDataset;

public class NormalDistributionExample {
    public static void main(String[] args) {
        // Create a normal distribution with mean 0 and standard deviation 1
        NormalDistribution normal = new NormalDistribution(0, 1);

        // Generate a random sample of 1000 values
        double[] values = normal.sample(1000);

        // Create a dataset for the histogram
        HistogramDataset dataset = new HistogramDataset();
        dataset.addSeries("Random Sample", values, 20); // 20 bins

        // Create a histogram chart
        String title = "Normal Distribution (μ=0, σ=1)";
        String xaxis = "Value";
        String yaxis = "Frequency";
        PlotOrientation orientation = PlotOrientation.VERTICAL;
        boolean show = false;
        boolean toolTips = false;
        boolean urls = false;
        org.jfree.chart.JFreeChart chart = ChartFactory.createHistogram(title, xaxis, yaxis, dataset, orientation, show, toolTips, urls);

        // Display the chart in a frame
        ChartFrame frame = new ChartFrame("Histogram", chart);
        frame.pack();
        frame.setVisible(true);
    }
}
