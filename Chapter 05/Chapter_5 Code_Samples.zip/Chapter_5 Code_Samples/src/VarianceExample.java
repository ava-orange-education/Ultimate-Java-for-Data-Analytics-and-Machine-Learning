import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

public class VarianceExample {
   public static void main(String[] args) {
      double[] data = { 2.1, 3.2, 4.5, 1.7, 6.9, 5.8, 8.0, 3.4, 4.7, 5.1 };
      
      DescriptiveStatistics stats = new DescriptiveStatistics(data);
      double variance = stats.getVariance();
      
      System.out.println("Variance of the dataset is: " + variance);
   }
}
