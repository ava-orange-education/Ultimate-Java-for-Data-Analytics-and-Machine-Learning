import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

public class StandardDeviationExample {
    public static void main(String[] args) {
        double[] numbers = { 2.5, 3.2, 1.8, 4.5, 2.6, 3.9, 4.2, 2.4 };
        DescriptiveStatistics stats = new DescriptiveStatistics();
        for (double num : numbers) {
            stats.addValue(num);
        }
        double stdDev = stats.getStandardDeviation();
        System.out.println("Standard Deviation: " + stdDev);
    }
}
