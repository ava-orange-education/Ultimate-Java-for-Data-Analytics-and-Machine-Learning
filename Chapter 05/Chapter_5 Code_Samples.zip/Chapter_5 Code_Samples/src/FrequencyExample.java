import java.util.Iterator;

import org.apache.commons.math3.stat.Frequency;

public class FrequencyExample {

   public static void main(String[] args) {

      // Create an array of data
      double[] data = {2.0, 2.5, 3.0, 3.5, 3.5, 4.0, 4.0, 4.5, 5.0, 5.0, 5.0};

      // Create a Frequency object
      Frequency freq = new Frequency();

      // Add the data to the frequency table
      for (double value : data) {
         freq.addValue(value);
      }

      // Print the frequency table
      System.out.println("Frequency table:");
      Iterator freqIt = freq.valuesIterator();
      while (freqIt.hasNext()) {
        Comparable<?> value = (Comparable<?>) freqIt.next();
        System.out.println(value + ": " + freq.getCount(value));
      }
   }
}
