import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

public class IQRExample {
    public static void main(String[] args) {
        double[] data = {1.2, 2.3, 3.5, 4.7, 5.8, 6.9, 7.1, 8.2, 9.4, 10.6};
        DescriptiveStatistics stats = new DescriptiveStatistics();
        for (double d : data) {
            stats.addValue(d);
        }
        double q1 = stats.getPercentile(25);
        double q3 = stats.getPercentile(75);
        double iqr = q3 - q1;
        System.out.println("Q1: " + q1);
        System.out.println("Q3: " + q3);
        System.out.println("IQR: " + iqr);
    }
}
