import org.apache.commons.math3.stat.descriptive.rank.Percentile;
import org.apache.commons.math3.distribution.NormalDistribution;

import java.util.Arrays;
import java.awt.Color;
import javax.swing.JFrame;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.ApplicationFrame;

public class QQPlotExample extends ApplicationFrame {

    public QQPlotExample(String title) {
        super(title);
    }

    public static void main(String[] args) {
        double[] data = {2.5, 3.2, 3.5, 4.1, 4.5, 4.8, 5.3, 5.6, 5.8, 6.1, 6.6, 7.2, 7.5, 7.9, 8.2, 8.6, 9.1, 9.5, 9.9, 10.3};

        Arrays.sort(data);

        NormalDistribution normalDist = new NormalDistribution();
        double[] theoreticalQuantiles = new double[data.length];
        for (int i = 0; i < data.length; i++) {
            theoreticalQuantiles[i] = normalDist.inverseCumulativeProbability((i + 1.0) / (data.length + 1.0));
        }

        double[] sampleQuantiles = new double[data.length];
        for (int i = 0; i < data.length; i++) {
            sampleQuantiles[i] = new Percentile().evaluate(data, (i + 1.0) / data.length * 100);
        }

        XYSeries series = new XYSeries("QQ Plot");
        for (int i = 0; i < data.length; i++) {
            series.add(theoreticalQuantiles[i], sampleQuantiles[i]);
        }

        XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(series);

        JFreeChart chart = ChartFactory.createScatterPlot(
                "QQ Plot",
                "Theoretical Quantiles",
                "Sample Quantiles",
                dataset,
                PlotOrientation.VERTICAL,
                true,
                true,
                false
        );

        XYPlot plot = chart.getXYPlot();
        plot.setBackgroundPaint(Color.white);

        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        rangeAxis.setAutoRangeIncludesZero(false);

        NumberAxis domainAxis = (NumberAxis) plot.getDomainAxis();
        domainAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        domainAxis.setAutoRangeIncludesZero(false);

        JFrame frame = new JFrame("QQ Plot Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(500, 270));
        frame.setContentPane(chartPanel);
        frame.pack();
        frame.setVisible(true);
    }
}
