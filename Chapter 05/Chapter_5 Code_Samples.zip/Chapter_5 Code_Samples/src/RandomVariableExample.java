import java.util.Random;

public class RandomVariableExample {
    public static void main(String[] args) {
        Random random = new Random();
        int dieRoll = random.nextInt(6) + 1; // generate a number between 1 and 6
        System.out.println("The roll of the die is: " + dieRoll);
    }
}
