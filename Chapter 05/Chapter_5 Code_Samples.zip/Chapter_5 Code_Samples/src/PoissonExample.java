import org.apache.commons.math3.distribution.PoissonDistribution;

public class PoissonExample {
    public static void main(String[] args) {
        PoissonDistribution poisson = new PoissonDistribution(5);

        for (int i = 0; i <= 10; i++) {
            System.out.println("P(X=" + i + ") = " + poisson.probability(i));
        }
    }
}
