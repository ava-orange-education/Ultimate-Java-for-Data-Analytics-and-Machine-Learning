import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

public class BoxPlotExample {

    public static void main(String[] args) {
        double[] data = {1.2, 2.1, 3.5, 4.2, 5.7, 6.8, 7.5, 8.2, 9.1, 10.0};
        
        DescriptiveStatistics stats = new DescriptiveStatistics(data);
        double q1 = stats.getPercentile(25);
        double q2 = stats.getPercentile(50);
        double q3 = stats.getPercentile(75);
        double iqr = q3 - q1;
        double upperWhisker = q3 + 1.5 * iqr;
        double lowerWhisker = q1 - 1.5 * iqr;
        
        System.out.println("Q1: " + q1);
        System.out.println("Q2: " + q2);
        System.out.println("Q3: " + q3);
        System.out.println("IQR: " + iqr);
        System.out.println("Upper Whisker: " + upperWhisker);
        System.out.println("Lower Whisker: " + lowerWhisker);
    }

}
