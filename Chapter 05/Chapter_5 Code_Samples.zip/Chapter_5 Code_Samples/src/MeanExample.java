import org.apache.commons.math3.stat.descriptive.moment.Mean;
//import org.apache.commons.math3.stat.descriptive.rank.Median;

public class MeanExample {
    public static void main(String[] args) {
        // Create an array of values
        double[] values = { 4.5, 3.0, 5.7, 2.6, 5.5, 9.2, 7.5, 5.5 };

        // Calculate the mean
        Mean mean = new Mean();
        double meanValue = mean.evaluate(values);
        System.out.println("Mean: " + meanValue);
    }
}
