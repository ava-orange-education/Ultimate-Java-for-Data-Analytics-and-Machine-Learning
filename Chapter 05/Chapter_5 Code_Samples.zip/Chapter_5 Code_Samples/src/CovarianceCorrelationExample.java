import org.apache.commons.math3.stat.correlation.Covariance;
import org.apache.commons.math3.stat.correlation.PearsonsCorrelation;

public class CovarianceCorrelationExample {

    public static void main(String[] args) {
        double[] x = {1, 2, 3, 4, 5};
        double[] y = {6, 7, 8, 9, 10};

        // calculate covariance
        Covariance covariance = new Covariance();
        double cov = covariance.covariance(x, y);
        System.out.println("Covariance: " + cov);

        // calculate correlation
        PearsonsCorrelation correlation = new PearsonsCorrelation();
        double corr = correlation.correlation(x, y);
        System.out.println("Correlation: " + corr);
    }
}
