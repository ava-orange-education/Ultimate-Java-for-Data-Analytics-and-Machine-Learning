import org.apache.commons.math3.distribution.BinomialDistribution;

public class BinomialExample {
    public static void main(String[] args) {
        int n = 10; // number of trials
        double p = 0.5; // probability of success
        int k = 3; // number of successes
        
        BinomialDistribution binomial = new BinomialDistribution(n, p);
        double probability = binomial.probability(k);
        
        System.out.println("Probability " + k + " successes in " + n + " trials with a probability of success " + p + " is " + probability);
    }
}
