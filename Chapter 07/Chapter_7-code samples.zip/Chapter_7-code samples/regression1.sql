 -- Create a new database
 CREATE DATABASE chapter7;

-- use the newly created database
 USE chapter7;

-- create table student_data
CREATE TABLE student_data (
  hours_studied FLOAT,
  marks_obtained FLOAT
);

-- insert some sample data into the table 'student_data'
INSERT INTO student_data (hours_studied, marks_obtained) VALUES 
(2.5, 21),
(5.1, 47),
(3.2, 27),
(8.5, 75),
(3.5, 30),
(1.5, 20),
(9.2, 88),
(5.5, 60),
(8.3, 81),
(2.7, 25),
(7.7, 85),
(5.9, 62),
(4.5, 41),
(3.3, 42),
(1.1, 17),
(8.9, 95),
(2.5, 30),
(1.9, 24),
(6.1, 67),
(7.4, 69),
(2.7, 30),
(4.8, 54),
(3.8, 35),
(6.9, 76),
(7.8, 86);

