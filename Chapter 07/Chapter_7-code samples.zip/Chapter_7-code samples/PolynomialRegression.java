import org.apache.commons.math3.analysis.polynomials.PolynomialFunction;
import org.apache.commons.math3.fitting.PolynomialCurveFitter;
import org.apache.commons.math3.fitting.WeightedObservedPoints;

public class PolynomialRegression {
    public static void main(String[] args) {
        // Create some sample data
        WeightedObservedPoints data = new WeightedObservedPoints();
        data.add(1.0, 2.0);
        data.add(2.0, 3.0);
        data.add(3.0, 4.0);
        data.add(4.0, 5.0);
        data.add(5.0, 6.0);

        // Create a polynomial curve fitter
        PolynomialCurveFitter fitter = PolynomialCurveFitter.create(2);

        // Fit the curve to the data
        double[] coefficients = fitter.fit(data.toList());

        // Create a polynomial function using the fitted coefficients
        PolynomialFunction function = new PolynomialFunction(coefficients);

        // Evaluate the function at a given value of X
        double x = 6.0;
        double y = function.value(x);

        System.out.println("Predicted value of Y at X = " + x + " is " + y);
    }
}
