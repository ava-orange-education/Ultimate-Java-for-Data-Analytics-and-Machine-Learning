import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import org.apache.commons.math3.stat.regression.SimpleRegression;

public class SimpleLinearRegressionExample {
  public static void main(String[] args) {
    try {
      // Connect to the database
      Connection connection = DriverManager.getConnection(
          "jdbc:mysql://localhost:3306/chapter7", "root", "admin");

      // Query the data
      Statement statement = connection.createStatement();
      ResultSet rs = statement.executeQuery("SELECT hours_studied, marks_obtained FROM student_data");

      // Create a SimpleRegression object
      SimpleRegression regression = new SimpleRegression();

      // Add the data points to the regression model
      while (rs.next()) {
        double x = rs.getDouble("hours_studied");
        double y = rs.getDouble("marks_obtained");
        regression.addData(x, y);
      }

      // Print the regression equation
      System.out.println("Fitting the Equation : Y = a + bX");
      double a = regression.getIntercept();
      double b = regression.getSlope();
      System.out.println("a = " + a + ", b = " + b);
      System.out.println("Regression equation: y = " + regression.getIntercept() + " + " + regression.getSlope() + "x");

      // Close the resources
      rs.close();
      statement.close();
      connection.close();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }
}
