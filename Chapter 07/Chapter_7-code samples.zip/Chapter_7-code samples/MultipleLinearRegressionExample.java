import org.apache.commons.math3.stat.regression.OLSMultipleLinearRegression;

public class MultipleLinearRegressionExample {
    public static void main(String[] args) {
        // Create the regression object
        OLSMultipleLinearRegression regression = new OLSMultipleLinearRegression();

        // Define the data matrix (independent variables)
        double[][] x = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}, {10, 11, 12}};

        // Define the response vector (dependent variable)
        double[] y = {2, 4, 6, 8};

        // Fit the model
        regression.newSampleData(y, x);
        double[] beta = regression.estimateRegressionParameters();

        // Print the coefficients
        System.out.println("Intercept: " + beta[0]);
        System.out.println("Coefficient 1: " + beta[1]);
        System.out.println("Coefficient 2: " + beta[2]);
        System.out.println("Coefficient 3: " + beta[3]);
    }
}
