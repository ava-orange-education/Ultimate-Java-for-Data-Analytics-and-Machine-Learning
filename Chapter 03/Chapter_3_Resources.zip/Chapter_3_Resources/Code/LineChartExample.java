import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.plot.PlotOrientation;

public class LineChartExample {

    public static void main(String[] args) {
        // create a dataset
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(10, "Series 1", "Category 1");
        dataset.addValue(20, "Series 1", "Category 2");
        dataset.addValue(30, "Series 1", "Category 3");
        dataset.addValue(40, "Series 1", "Category 4");
        dataset.addValue(50, "Series 1", "Category 5");

        // create the chart
        JFreeChart chart = ChartFactory.createLineChart(
            "Line Chart Example", // chart title
            "Category", // domain axis label
            "Value", // range axis label
            dataset, // data
            PlotOrientation.VERTICAL, // orientation
            true, // include legend
            true, // tooltips
            false // urls
        );

        // display the chart
        ChartFrame frame = new ChartFrame("Line Chart", chart);
        frame.pack();
        frame.setVisible(true);
    }
}
