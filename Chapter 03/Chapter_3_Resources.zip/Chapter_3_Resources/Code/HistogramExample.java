import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.statistics.HistogramDataset;

public class HistogramExample {
    public static void main(String[] args) {
        // Create a dataset with the data to plot
        double[] data = {1.2, 2.3, 3.4, 4.5, 5.6, 6.7, 7.8, 8.9, 9.0, 10.1};
        HistogramDataset dataset = new HistogramDataset();
        dataset.addSeries("Data", data, 10);

        // Create a chart with the dataset
        JFreeChart chart = ChartFactory.createHistogram(
                "Histogram Example", // chart title
                "Value", // x axis label
                "Frequency", // y axis label
                dataset, // dataset
                PlotOrientation.VERTICAL, // plot orientation
                true, // show legend
                true, // tooltips
                false // urls
        );

        // Create a frame to display the chart
        ChartFrame frame = new ChartFrame("Histogram Example", chart);
        frame.pack();
        frame.setVisible(true);
    }
}
