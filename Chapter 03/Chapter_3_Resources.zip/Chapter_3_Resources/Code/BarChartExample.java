import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.chart.renderer.category.BarRenderer;

public class BarChartExample {
    public static void main(String[] args) {
        // Step 1: Create the dataset
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.setValue(50, "Sales", "January");
        dataset.setValue(70, "Sales", "February");
        dataset.setValue(90, "Sales", "March");

        // Step 2: Create the chart
        JFreeChart chart = ChartFactory.createBarChart("Monthly Sales", "Month", "Sales", dataset, PlotOrientation.VERTICAL, false, true, false);

        // Step 3: Create the plot
        CategoryPlot plot = chart.getCategoryPlot();

        // Step 4: Create the renderer
        BarRenderer renderer = (BarRenderer) plot.getRenderer();
        renderer.setSeriesPaint(0, java.awt.Color.blue);

        // Step 5: Display the chart
        ChartFrame frame = new ChartFrame("Monthly Sales", chart);
        frame.pack();
        frame.setVisible(true);
    }
}
