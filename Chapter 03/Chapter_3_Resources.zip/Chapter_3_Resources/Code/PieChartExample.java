import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
import javax.swing.JFrame;

public class PieChartExample {
    public static void main(String[] args) {
        // Create a dataset
        DefaultPieDataset dataset = new DefaultPieDataset();
        dataset.setValue("Java", 25);
        dataset.setValue("Python", 40);
        dataset.setValue("C++", 15);
        dataset.setValue("JavaScript", 10);
        dataset.setValue("Other", 10);

        // Create a chart
        JFreeChart chart = ChartFactory.createPieChart("Programming Language Popularity", dataset, true, true, false);

        // Create a ChartPanel
        ChartPanel chartPanel = new ChartPanel(chart);

        // Add the ChartPanel to a JFrame
        JFrame frame = new JFrame("Pie Chart Example");
        frame.setContentPane(chartPanel);
        frame.pack();
        frame.setVisible(true);
    }
}
