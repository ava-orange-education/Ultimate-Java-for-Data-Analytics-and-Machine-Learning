import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BoxAndWhiskerRenderer;
import org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset;

public class BoxPlotExample {
    public static void main(String[] args) {
        // create dataset
        DefaultBoxAndWhiskerCategoryDataset dataset = new DefaultBoxAndWhiskerCategoryDataset();
        List<Double> values1 = new ArrayList<Double>();
        values1.add(2.3);
        values1.add(3.1);
        values1.add(2.8);
        values1.add(3.5);
        values1.add(3.6);
        List<Double> values2 = new ArrayList<Double>();
        values2.add(2.7);
        values2.add(2.9);
        values2.add(3.1);
        values2.add(3.4);
        values2.add(3.2);
        dataset.add(values1, "Series 1", "Category 1");
        dataset.add(values2, "Series 1", "Category 2");

        // create chart
        CategoryAxis xAxis = new CategoryAxis("Category");
        NumberAxis yAxis = new NumberAxis("Value");
        BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
        CategoryPlot plot = new CategoryPlot(dataset, xAxis, yAxis, renderer);
        JFreeChart chart = new JFreeChart("Box and Whisker Chart", plot);
        chart.setBackgroundPaint(Color.white);

        // display chart
        ChartFrame frame = new ChartFrame("Box and Whisker Chart Example", chart);
        frame.pack();
        frame.setVisible(true);
    }
}
