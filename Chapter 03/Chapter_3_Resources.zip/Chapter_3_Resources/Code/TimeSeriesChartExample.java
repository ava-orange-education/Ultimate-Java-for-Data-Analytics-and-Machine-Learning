import java.util.Date;
import org.jfree.data.time.*;
import org.jfree.chart.*;
import org.jfree.chart.axis.*;
import org.jfree.chart.plot.*;
import org.jfree.chart.renderer.xy.*;

public class TimeSeriesChartExample {

    public static void main(String[] args) {

        // Create a TimeSeries collection
        TimeSeriesCollection dataset = new TimeSeriesCollection();

        // Add a TimeSeries to the dataset
        TimeSeries series = new TimeSeries("Stock Price");

        // Add data to the TimeSeries
        series.add(new Day(1, 1, 2022), 20.5);
        series.add(new Day(2, 1, 2022), 21.3);
        series.add(new Day(3, 1, 2022), 21.0);
        series.add(new Day(4, 1, 2022), 21.7);
        series.add(new Day(5, 1, 2022), 22.0);
        series.add(new Day(6, 1, 2022), 22.1);
        series.add(new Day(7, 1, 2022), 21.8);

        // Add the TimeSeries to the dataset
        dataset.addSeries(series);

        // Create a chart
        JFreeChart chart = ChartFactory.createTimeSeriesChart(
                "Stock Price", // chart title
                "Date", // x-axis label
                "Price", // y-axis label
                dataset, // data
                true, // legend
                true, // tooltips
                false // urls
        );

        // Customize the chart
        XYPlot plot = chart.getXYPlot();
        DateAxis axis = (DateAxis) plot.getDomainAxis();
        axis.setDateFormatOverride(new java.text.SimpleDateFormat("MMM-yyyy"));
        plot.setRenderer(new XYLineAndShapeRenderer(true, false));
        plot.setBackgroundPaint(java.awt.Color.white);
        plot.setRangeGridlinesVisible(true);
        plot.setRangeGridlinePaint(java.awt.Color.lightGray);
        chart.setBackgroundPaint(java.awt.Color.white);

        // Display the chart
        ChartFrame frame = new ChartFrame("Time Series Chart Example", chart);
        frame.pack();
        frame.setVisible(true);
    }
}
